﻿var BoxR;
(function (BoxR) {
    var dummychars = "Ù";
    (function (Manager) {
        Manager.Connection;
        Manager.Hub;
        Manager.Server;
        Manager.Client;
        Manager.Game;
        Manager.PopupControl;
    })(BoxR.Manager || (BoxR.Manager = {}));
    var Manager = BoxR.Manager;
})(BoxR || (BoxR = {}));
