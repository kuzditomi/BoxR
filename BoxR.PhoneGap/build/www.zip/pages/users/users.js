﻿function initUsers() {
    BoxR.Manager.Server.UpdateUsers();
}