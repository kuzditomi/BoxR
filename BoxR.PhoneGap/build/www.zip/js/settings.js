﻿var fbclientid = '135351466628620';
var fbsecret = '16a864275e4566042edcf58ae6d87b76';